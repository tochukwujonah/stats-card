# Frontend Mentor - Stats preview card component solution

This is a solution to the [Stats preview card component challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/stats-preview-card-component-8JqbgoU62). Frontend Mentor challenges help you improve your coding skills by building realistic projects. 

## Table of contents

- [Overview](#overview)
  - [The challenge](#the-challenge)
  - [Screenshot](#screenshot)
  - [Links](#links)
- [My process](#my-process)
  - [Built with](#built-with)
  - [What I learned](#what-i-learned)
- [Author](#author)
- [Acknowledgments](#acknowledgments)

**Note: Delete this note and update the table of contents based on what sections you keep.**

## Overview

### The challenge

Users should be able to:

- View the optimal layout depending on their device's screen size

### Screenshot

![](./screenshot.jpg)


### Links

- Solution URL: [Add solution URL here](https://your-solution-url.com)
- Live Site URL: [Add live site URL here](https://your-live-site-url.com)

## My process

### Built with

- Semantic HTML5 markup
- CSS custom properties
- Flexbox
- Mobile-first workflow


### What I learned

This projects helped me work on my CSS skill. Major learning point for me was when I had to create a background overlay over an image, as simple as it turned out to be, it was a hard-nut to crack.



```html
<div class="image">
      <img srcset="../stats-preview-card-component-main/images/image-header-mobile.jpg 370w,
                  ../stats-preview-card-component-main/images/image-header-desktop.jpg 540w"
                  sizes="100vw"
                 src="../stats-preview-card-component-main/images/image-header-desktop.jpg 540w" alt=""/>      
    </div>
```
```CSS
.image{
        height: 250px;
        width: 345px;
        background-color: hsl(277, 64%, 61%);
        border-radius: 5px 5px 0px 0px;
    }
    
    img{
        height: 250px;
        width: 345px;
        border-radius: 5px 5px 0px 0px;
        opacity: 0.47;
    }    
```


## Author

- Website - [Add your name here](https://www.your-site.com)
- Frontend Mentor - [@ysirtch](https://www.frontendmentor.io/profile/sirtch)
- Twitter - [@jonahtochukwu](https://www.twitter.com/jonahtochukwu)



## Acknowledgments
